
package prj_5026231182;

import java.util.*;

public class ArrayWrapper {
    public static void main(String[] array) {
        Scanner sc = new Scanner(System.in);
        Random rn = new Random();
        int r = rn.nextInt();      
        int n = 0;
        for(int i=0; i<n; i++){
           if(n%2==0){
               System.out.println("even");
           }else
                System.out.println("odd");
       } 
    }
}
