
package prj_5026231182;

public class wrapper {
    public static void main(String[] args) {
        int[][] num = new int[1][4];
        
        num[0][0] = 1;
        num[0][1] = 4;
        num[0][2] = 7;
        num[0][3] = 3;
        
        System.out.println("");
    }
  
}
