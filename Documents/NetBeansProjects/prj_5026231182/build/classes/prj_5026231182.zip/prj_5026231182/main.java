
package prj_5026231182;

public class main {
    public static void main(String[] args) {
        String lamp;
        int n = 0;
        
        for(int i=0; i<n; i++){
            
        }
        
        System.out.print();
    }
}
