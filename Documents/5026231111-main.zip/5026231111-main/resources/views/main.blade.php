<head>
    <link rel="stylesheet" href="style.css"
    <body>
        <div class="product-list">
            <div class="product-card">
                <h3>Shampoo</h3>
                <p class="price">70.000</p>
                <p>Anti rontok, anti ketombe</p>
                <button>Buy Now</button>
            </div>

            <div class="product-card">
                <h3>Body Wash</h3>
                <p class="price">90.000</p>
                <p>Moisturizing</p>
                <button>Buy Now</button>
            </div>

            <div class="product-card">
                <h3>Facial Wash</h3>
                <p class="price">100.000</p>
                <p>For oily skin</p>
                <button>Buy Now</button>
            </div>

            <div class="product-card">
                <h3>Sunscreen</h3>
                <p class="price">45.000</p>
                <p>spf 50++</p>
                <button>Buy Now</button>
            </div>

        </div>
    </body>
</head>